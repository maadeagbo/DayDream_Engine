#pragma once

#include "config.h"
#include "DD_MathLib.h"
#include "DD_GameLevel.h"
#include "ControllerA.h"

class AIStandalone : public DD_GameLevel
{
public:
	AIStandalone() {}
	~AIStandalone() {}

	void Init();
	DD_Event basePost(DD_Event& event);
	void generatePRM();
private:

};