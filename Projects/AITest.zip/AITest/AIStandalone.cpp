#include "AIStandalone.h"

struct Node {
	glm::vec3 color;
	int index = -1, parent_index = -1;
	bool closed = false;
	dd_array<LinePoint> connections;
	dd_array<glm::vec2> costs;
	float cost_to_current = 0.f;
};

struct Q_Node {
	int index = -1, parent_index = -1;
	float cost_to_current = 0.f;
	void set(const Node* n) {
		index = n->index;
		parent_index = n->parent_index;
		cost_to_current = n->cost_to_current;
	}
};

namespace {
	enum sims { WATER, FIRE, MAGIC, BALL, CLOTH, NUM_SIMS };

	ControllerA* myControl;
	DD_Agent* l_bulbs = nullptr;
	DD_Agent* _floor = nullptr;
	size_t num_obstacles = 2;
	DD_Agent* obstacle01;
	DD_Agent* ai_agent = nullptr;
	DD_Camera* cam;
	DD_Light* light;
	bool makeParticleFlag = true, generate_tree = true, line_render = true;
	bool simFlags[sims::NUM_SIMS] = { false, true };
	int fireCount = 0, emitterIndex = 0, mouseXPos = 0.f, mouseYPos = 0.f;
	dd_array<glm::vec3> obst = dd_array<glm::vec3>(num_obstacles);
	dd_array<float> radi = dd_array<float>(num_obstacles);

	// AI stuff
	int seed = 0;
	bool move_agent = false;
	float agent_speed = 500.5f;
	int num_nodes = 20;
	size_t last_seen_node = 0;
	size_t p_q_size = 0;
	size_t c_q_size = 0;
	dd_array<glm::vec3> plots;
	dd_array<LinePoint> temp_lines;
	dd_array<glm::vec2> temp_cost;
	dd_array<size_t> a_path = dd_array<size_t>(1);

	glm::vec3 startP = glm::vec3(-1309.f, 0.f, 1390.f);
	glm::vec3 endP = glm::vec3(1387.f, -0.f, -1393.f);

	dd_array<Node> _nodes = dd_array<Node>(num_nodes);
	dd_array<float> h_costs = dd_array<float>(num_nodes);
	dd_array<Q_Node> p_queue = dd_array<Q_Node>(num_nodes);
	dd_array<size_t> c_queue = dd_array<size_t>(num_nodes);
}

void AIStandalone::Init() {
	// register skybox map
	//m_cubeMapID = "water";
	// add meshes to level
	myControl = new ControllerA("avatar");
	AddAgent(myControl);
	myControl->clickedP = false;
	myControl->clickedT = false;
	myControl->clickedSpace = false;
	myControl->UpdatePosition(glm::vec3(0.0f, 1000.0f, 3500.0f));

	_floor = GetGenericAgent("Floor", "floor");
	_floor->UpdateScale(glm::vec3(2.f));

	l_bulbs = GetGenericAgent("light_bulbs", "ball");

	obstacle01 = GetGenericAgent("Obstacle", "cylinder");
	dd_array<glm::mat4> ob_inst = dd_array<glm::mat4>(num_obstacles);
	obst[0] = glm::vec3(ob_inst[0][3]);
	obst[1] = glm::vec3(ob_inst[1][3]);
	obstacle01->SetInstances(ob_inst);

	ai_agent = GetGenericAgent("AI", "cylinder2");
	ai_agent->UpdatePosition(startP);

	// Add shadow light
	light = GetGenericLight("shadow");
	light->m_position = glm::vec3(1000.0f, 1000.f, 2000.0f);
	//light->m_position = glm::vec3(0.0f, 0.f, 0.0f);
	light->m_color = glm::vec3(0.1f);
	//light->m_type = LightType::POINT_L;
	//light->m_linear = 0.07f;
	//light->m_quadratic = 0.017f;
	light->m_flagShadow = true;

	// add generic camera
	cam = GetGenericCamera("myCam");
	cam->m_active = true;
	cam->m_near_plane = 1.0f;
	cam->m_far_plane = 10000.0f;
	cam->SetParent(myControl->m_ID.c_str());

	//  callbacks and posts
	EventHandler a = std::bind(&AIStandalone::basePost, this, std::placeholders::_1);
	AddCallback("post", a);
}

void AIStandalone::generatePRM() {
	// randomly plot points on screen
	if (generate_tree) {
		generate_tree = false;
		plots.resize(num_nodes);
		temp_lines.resize(num_nodes - 1);
		temp_cost.resize(num_nodes - 1);
		_nodes.resize(num_nodes);
		h_costs.resize(num_nodes);
		p_queue.resize(num_nodes);
		c_queue.resize(num_nodes);
		dd_array<glm::vec3> colors = dd_array<glm::vec3>(num_nodes);
		dd_array<glm::mat4> temp_mats = dd_array<glm::mat4>(num_nodes);

		// sample floor for points
		_floor->cleanInst();
		BoundingBox bbox = _floor->BBox.transformCorners(_floor->m_instances[0]);
		DD_MathLib::randomSampleRect(_floor->pos(), bbox.min, bbox.max, plots, 
			(unsigned int)seed);

		for (size_t i = 0; i < plots.size(); i++) {
			temp_mats[i] = glm::translate(glm::mat4(), plots[i]);
			temp_mats[i] = glm::scale(temp_mats[i], glm::vec3(0.6));
			colors[i] = glm::vec3(1.f, 1.f, 1.f);
		}
		// load up colors and markers
		l_bulbs->SetInstances(temp_mats);
		l_bulbs->SetColorInstances(colors);
		
		//reset obstacles
		num_obstacles = 2;
		obst.resize(num_obstacles);
		radi.resize(num_obstacles);
		dd_array<glm::mat4> ob_inst = dd_array<glm::mat4>(2);
		obst[0] = glm::vec3(ob_inst[0][3]);
		obst[1] = glm::vec3(ob_inst[1][3]);
		obstacle01->SetInstances(ob_inst);
	}
	// load up lines and obstacles
	for (size_t i = 0; i < num_obstacles; i++) {
		ai_agent->cleanInst();
		BoundingBox bb1 = obstacle01->BBox.transformCorners(
			obstacle01->m_instances[i]);
		BoundingBox bb2 = ai_agent->BBox.transformCorners(ai_agent->m_instances[0]);
		float x1 = (bb1.max.x - bb1.min.x) / 2.f;
		float x2 = (bb2.max.x - bb2.min.x) / 2.f;
		radi[i] = x1 + x2;
	}
	
	// clean out line bin
	ResSpace::FlushLineAgents(m_res);

	// set start and goal positions
	plots[0] = startP;
	l_bulbs->m_instColors[0] = glm::vec3(1.f, 0.f, 0.f);
	ai_agent->UpdatePosition(startP);
	plots[1] = endP;
	l_bulbs->m_instColors[1] = glm::vec3(1.f, 0.f, 1.f);

	// reset A* stuff
	last_seen_node = 0;

	for (size_t i = 0; i < num_nodes; i++) {
		DD_LineAgent* la = GetGenericLineAgent("first");
		size_t numL = DD_MathLib::calculateLOSLines(i, obst, radi, plots,
			temp_lines, temp_cost);
		la->lines.resize(numL);
		la->lines = temp_lines;

		// load nodes
		_nodes[i].index = i;
		_nodes[i].connections.resize(numL);
		_nodes[i].connections = temp_lines;
		_nodes[i].costs.resize(numL);
		_nodes[i].costs = temp_cost;

		// calculate heuristics using manhattan distance
		h_costs[i] = glm::distance(endP, plots[i]);
	}
}

// Remove element from priority queue
void removeFromPriorityQ(const int index) {
	if (index < 0) {
		return;
	}
	const size_t steps = (p_q_size - 1) - index;
	for (size_t i = index; i < p_q_size; i++) {
		p_queue[i] = std::move(p_queue[i + 1]);
	}
	p_q_size -= 1;
}

// Verify / Add node to frontier
void addToPriorityQ(Node* new_node, const float _cost, const float _hcost, 
	const size_t parent) 
{
	if (p_q_size == 0) {
		new_node->cost_to_current = _cost;
		new_node->parent_index = parent;
		p_queue[0].set( new_node );
		p_q_size += 1;
	}
	else {
		// sort by score
		float _g = _cost + new_node->cost_to_current;
		float total = _g + _hcost;

		// check if node already exists in tree (if new_node has smaller cost,
		// remove older version of node, set updated costs, resort queue)
		bool duplicate = false;
		size_t counter = 0;
		while (!duplicate && counter < p_q_size) {
			int saved_index = p_queue[counter].index;
			if (saved_index == new_node->index) {
				duplicate = true;
			}
			counter += 1;
		}
		if (duplicate) {
			float old_cost = p_queue[counter - 1].cost_to_current;
			if (old_cost > _g) {
				removeFromPriorityQ(counter - 1); // remove then replace
			}
			else {
				return; // older node has a lower G cost so skip new_node
			}
		}

		// update score and place node in sorted order (bottom --> up loop)
		new_node->parent_index = parent;
		new_node->cost_to_current = _g;
		bool placed_node = false;
		for (int i = (p_q_size - 1); i >= 0 && !placed_node; i--) {
			//printf("Index = %zd\n", i);
			Node* p_node = &_nodes[p_queue[i].index];
			size_t index = p_node->index;
			float f_cost = h_costs[index] + p_queue[i].cost_to_current;
			//printf("node G = %f\n", _g);
			//printf("node F = %f\n", total);
			//printf("F cost = %f\n", f_cost);
			if (total < f_cost) {
				// move node being checked against lower on queue
				p_queue[i + 1] = std::move(p_queue[i]);
				p_queue[i].set(new_node);
			}
			else {
				// place current node in correct spot
				p_queue[i + 1].set(new_node);
				placed_node = true;
			}
		}
		p_q_size += 1;
	}
}

// Add expanded node to closed list
size_t addToCLosedQ(Node* old_node) {
	old_node->closed = true;
	c_queue[c_q_size] = old_node->index;
	c_q_size += 1;
	removeFromPriorityQ(0);
	return old_node->index;
}

void expandNode(Node* old_node) {
	// expand all node connections and add to frontier
	for (size_t i = 0; i < old_node->connections.size(); i++) {
		size_t index = (size_t)old_node->costs[i].x;
		Node* new_node = &_nodes[index];
		if (new_node->closed) {
			continue;					// skip current node (already explored)
		}
		new_node->cost_to_current = old_node->cost_to_current;

		addToPriorityQ(new_node, old_node->costs[i].y, h_costs[index], old_node->index);
	}
}

dd_array<size_t> planA_Star() {
	// reset
	p_q_size = 0;
	c_q_size = 0;
	for (size_t i = 0; i < num_nodes; i++) {
		_nodes[i].closed = false;
		_nodes[i].cost_to_current = 0.f;
		_nodes[i].parent_index = -1;
	}
	for (size_t i = 2; i < num_nodes; i++) {
		l_bulbs->m_instColors[i] = glm::vec3(1.f);
	}

	dd_array<size_t> path = dd_array<size_t>(num_nodes);
	Node* start_n = &_nodes[0];
	size_t last_node = 0, path_length = 0;
	
	addToPriorityQ(start_n, 0, h_costs[0], -1);
	// expand highest node in queue until end node is at the top
	while (p_queue[0].index != 1) {
		// send current node to the closed list
		last_node = addToCLosedQ(&_nodes[p_queue[0].index]);

		expandNode(&_nodes[last_node]);
	}
	// reconstruct optimal path
	int next_node = 1;
	while (next_node != 0) {
		//printf("Previous node: %d\n", next_node);
		path[path_length] = next_node;
		path_length += 1;
		next_node = _nodes[next_node].parent_index;
		if (next_node != 0) {
			l_bulbs->m_instColors[next_node] = glm::vec3(0.f, 1.f, 0.f);
		}
	}
	dd_array<size_t> new_path = dd_array<size_t>(path_length);
	//printf("Length: %d\n", path_length);
	//printf("Path: %d\n", 0);
	for (size_t i = 1; i < path_length; i++) { 
		new_path[i - 1] = path[path_length - i]; // ofset to get points after 1st 
		//printf("Path: %zd\n", path[path_length - i]);
	}
	new_path[path_length - 1] = 1;
	//printf("Path: %d\n", 1);

	return new_path;
}

void moveAgentAlongPath(float dt) {
	if (a_path.size() == 1) {
		glm::vec3 pos = ai_agent->pos();
		glm::vec3 ray = endP - pos;
		if (glm::length(ray) <= 10.f) {
			move_agent = false;
			return;
		}
		ray.y = 0.f;
		ray = glm::normalize(ray);
		glm::vec3 new_p = pos + (ray * agent_speed * dt);
		ai_agent->UpdatePosition(new_p);
	}
	else {
		bool no_intersect = true;
		glm::vec3 pos = ai_agent->pos();
		int index = a_path.size() - 1;
		for (int i = last_seen_node; i < a_path.size() && no_intersect; i++) {
			glm::vec3 ray = plots[a_path[i]] - pos;
			dd_array<bool> hit = dd_array<bool>(num_obstacles);
			for (size_t j = 0; j < num_obstacles; j++) {
				hit[j] = DD_MathLib::checkRayCircle(ray, pos, obst[j], radi[j]);
				if (hit[j]) {
					no_intersect = false;
					index = i - 1;
				}
			}
		}
		// plot course
		last_seen_node = (index < last_seen_node) ? last_seen_node : index;
		glm::vec3 ray = plots[a_path[index]] - pos;
		if (glm::length(ray) <= 10.f) {
			move_agent = false;
			return;
		}
		ray.y = 0.f;
		ray = glm::normalize(ray);
		glm::vec3 new_p = pos + (ray * agent_speed * dt);
		ai_agent->UpdatePosition(new_p);
	}
}

DD_Event AIStandalone::basePost(DD_Event& event) {
	bool line_switch = false;
	if (event.m_type.compare("post") == 0) {
		timeData* _time = static_cast<timeData*>(event.m_message);

		//* imgui interface sims
		ImGuiWindowFlags window_flags = 0;
		ImGui::Begin("Controls", nullptr, window_flags);
		ImGui::InputInt("Number of Nodes", &num_nodes);
		ImGui::InputInt("PRM Seed", &seed);
		if (ImGui::Button("Regenerate PRM and Obstacles")) { 
			generate_tree = true;
			generatePRM(); 
		}
		if (generate_tree) {
			if (ImGui::Button("Load PRM")) { generatePRM(); }
		}
		else {
			if (ImGui::Button("Reload PRM")) { generatePRM(); }
		}
		ImGui::SameLine();
		if (ImGui::Button("Add Obstacle")) { 
			num_obstacles += 1;
			dd_array<glm::mat4> ob_inst = dd_array<glm::mat4>(num_obstacles);
			ob_inst = obstacle01->m_instances;
			obstacle01->SetInstances(ob_inst);

			dd_array<glm::vec3> t_obst = dd_array<glm::vec3>(num_obstacles);
			dd_array<float> t_radi = dd_array<float>(num_obstacles);
			t_obst = std::move(obst);
			t_radi = std::move(radi);
			obst.resize(num_obstacles);
			radi.resize(num_obstacles);
			obst = t_obst;
			radi = t_radi;
		}
		if (!generate_tree) {
			ImGui::SameLine();
			if (ImGui::Button("Plan Path")) { a_path = std::move(planA_Star()); }
		}
		if (!generate_tree) {
			ImGui::SameLine();
			if (ImGui::Button("Lines")) { 
				line_switch = true;
				line_render ^= 1; 
			}
		}
		if (!generate_tree) {
			ImGui::SameLine();
			if (ImGui::Button("Go!!!")) { move_agent ^= 1; }
		}
		ImGui::SliderFloat3("Start", &startP[0], -1400.f, 1400.f);
		ImGui::SliderFloat3("Goal", &endP[0], -1400.f, 1400.f);
		for (size_t i = 0; i < num_obstacles; i++) {
			std::string n = "Obstacle " + std::to_string(i);
			ImGui::SliderFloat3(n.c_str(), &obst[i][0], -1400.f, 1400.f); 
			ImGui::SameLine();
			n = "Reset " + std::to_string(i);
			if (ImGui::Button(n.c_str())) { obst[i] = glm::vec3(); }
		}
		ImGui::End();
		//*/
		for (size_t i = 0; i < num_obstacles; i++) {
			obstacle01->m_instances[i] = glm::translate(glm::mat4(), obst[i]) *
				glm::scale(glm::mat4(), glm::vec3(10.f));;
		}
		if (!generate_tree) {
			l_bulbs->m_instances[0] = glm::translate(glm::mat4(), startP);
			l_bulbs->m_instances[1] = glm::translate(glm::mat4(), endP);
			//ai_agent->UpdatePosition(startP);
		}
		if (move_agent) {
			moveAgentAlongPath(_time->frameTime);
		}
		
		// ground level cam
		if (myControl->pos().y < 10.0f) {
			glm::vec3 _pos = myControl->pos();
			myControl->UpdatePosition(glm::vec3(_pos.x, 10.0f, _pos.z));
		}

		if (line_switch) {
			// turn on and off line rendering
			DD_Event newEvent = DD_Event();
			newEvent.m_type = "LineRend";

			flagBuff* fb = new flagBuff();
			fb->flag = line_render;
			newEvent.m_message = fb;

			return newEvent;
		}

		makeParticleFlag = myControl->clickedP;
		
		if (makeParticleFlag && simFlags[sims::FIRE]) {
			DD_Event newEvent = DD_Event();
			newEvent.m_type = "generate_emitter";

			emitterInit* init = new emitterInit();
			init->ID = "fire" + std::to_string(fireCount);
			fireCount += 1;

			init->textureSet = RenderTextureSets::FIRE01;
			init->parentID = "";
			init->radius = 50.f;
			init->type = EmitterType::FIRE;
			init->size = 4.f;

			glm::vec3 myP = myControl->pos();
			myP += myControl->ForwardDir() * 500.f;
			glm::mat4 mat = glm::translate(glm::mat4(), glm::vec3(myP.x, 0.f, myP.z));

			init->model = mat;
			init->lifetime = 10.f;
			init->emitPerSec = 1000.0f;
			init->deathRate = 2.0;
			init->rotPerSec = 2;
			init->direction = glm::rotate(glm::mat4(), glm::radians(5.f),
				glm::vec3(0.f, 0.f, 1.f));
			init->velUp = 150.0f;

			newEvent.m_message = init;
			myControl->clickedP = false;

			return newEvent;
		}
		if (myControl->clickedT) {
			event.m_type = "system_pause";
			myControl->clickedT = false;
		}
		if (myControl->clickedLM) {
			mouseXPos = myControl->mouseX;
			mouseYPos = myControl->mouseY;
			//printf("Clicked\n");
			//printf("X: %d, Y: %d\n", mouseXPos, mouseYPos);

			raycastBuff rcb = DD_MathLib::rayCast(mouseXPos, mouseYPos, "Floor");
			if (rcb.hit) {
				//printf("Hit: x: %f, y: %f, z: %f\n", 
					//rcb.pos.x, rcb.pos.y, rcb.pos.z);
			}
			myControl->clickedLM = false;
		}
		return DD_Event();
	}
}
