#pragma once

#include "DD_Agent.h"

class ControllerA : public DD_Agent {
public:
	ControllerA(const char* ID, const char* model = "", const char* parent = "");
	~ControllerA() {}

	DD_Event Update(DD_Event event);

	bool clickedP = false, clickedT = false, clickedSpace = false, 
		clickedRA = false, clickedLA = false, clickedLM = false, clickedEsc = false;
	int mouseX = 0.f, mouseY = 0.f;
private:

};
