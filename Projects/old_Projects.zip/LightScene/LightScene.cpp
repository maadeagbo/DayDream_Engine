#include "LightScene.h"

namespace {
	enum sims { WATER, FIRE, MAGIC, BALL, CLOTH, NUM_SIMS };

	Controller* myControl;
	DD_Agent* ball;
	DD_Camera* cam;
	DD_Light* light;
}

LightScene::LightScene() {
	// add resource file containing all assets
	m_resourceFile = PROJECT_DIR + "LightScene/assets";
	// register skybox map
	//m_cubeMapID = "water";
	// add meshes to level
	myControl = new Controller("avatar");
	AddAgent(myControl);
	myControl->clickedP = false;
	myControl->clickedT = false;
	myControl->clickedSpace = false;
	myControl->UpdatePosition(glm::vec3(0.0f, 80.0f, 500.0f));

	DD_Agent* agent1 = GetGenericAgent("Floor", "floor");
	//agent1->UpdateScale(glm::vec3(100.f));

	//ball = GetGenericAgent("Ball_Red", "ball");
	//ball->UpdateScale(glm::vec3(4.f));

	// Add shadow light
	light = GetGenericLight("shadow");
	light->m_position = glm::vec3(0.0f, 0.f, 0.0f);
	light->m_color = glm::vec3(1.f, 1000.f, 1.f);
	light->m_type = LightType::POINT_L;
	light->m_linear = 0.07f;
	light->m_quadratic = 0.017f;
	//light->m_flagShadow = true;

	// fire light
	//DD_Light* FL01 = GetGenericLight("fire");
	//FL01->m_type == LightType::POINT_L;
	//FL01->m_attenuation = .001;

	// add generic camera
	cam = GetGenericCamera("myCam");
	cam->m_active = true;
	cam->m_far_plane = 8000.0f;
	cam->SetParent(myControl->m_ID.c_str());
	cam->m_vr_cam = false;
	if (cam->m_vr_cam) {
		cam->m_vrScrPos = glm::vec3(0.0f, 0.0f, 0.0f);
		cam->m_vrEyePos = myControl->pos();
		m_scrHorzDist = 0.9271f;
		m_scrVertDist = 0.5207f;		
	}

	//  callbacks and posts
	EventHandler a = std::bind(&LightScene::basePost, this, std::placeholders::_1);
	AddCallback("post", a);
	AddCallback("VR", a);
}

DD_Event LightScene::basePost(DD_Event& event) {

	if (event.m_type == "VR") {
		cam->m_vrEyePos = myControl->pos();
		return DD_Event();
	}

	if (event.m_type.compare("post") == 0) {
		timeData* time = static_cast<timeData*>(event.m_message);
		// ground level cam
		if (myControl->pos().y < 50.0f) {
			glm::vec3 _pos = myControl->pos();
			//myControl->UpdatePosition(glm::vec3(_pos.x, 50.0f, _pos.z));
		}
		return DD_Event();
	}
}
