#include "ControllerL.h"

namespace {
	float speed = 250.0f, mouseSensitivity = 0.5f, Pitch, Yaw;
	float lastClick = 0.f;
	glm::quat OriginalRot;
}

ControllerL::ControllerL(const char * ID, const char * model, const char * parent) :
	clickedP(false), clickedT(false), clickedSpace(false), clickedRA(false),
	clickedLA(false)
{
	m_ID = ID;
	// store function pointer
	EventHandler update =
		std::bind(&ControllerL::Update, this, std::placeholders::_1);

	OriginalRot = rot();
	AddCallback("input", update);
}

DD_Event ControllerL::Update(DD_Event event) {
	// Parse throught events
	if (event.m_type == "input") {
		glm::vec3 forward = ForwardDir() * speed * event.m_time;
		glm::vec3 right = RightDir() * speed * event.m_time;
		lastClick += event.m_time;
		//*
		inputBuff* input = (inputBuff*)event.m_message;
		if (input->rawInput[DD_Keys::W_Key]) {
			UpdatePosition(pos() + forward);
		}
		if (input->rawInput[DD_Keys::A_Key]) {
			UpdatePosition(pos() - right);
		}
		if (input->rawInput[DD_Keys::S_Key]) {
			UpdatePosition(pos() - forward);
		}
		if (input->rawInput[DD_Keys::D_Key]) {
			UpdatePosition(pos() + right);
		}
		if (input->rawInput[DD_Keys::P_Key] && lastClick > 0.5f) {
			clickedP = !clickedP;
			lastClick = 0.f;
		}
		if (input->rawInput[DD_Keys::T_Key] && lastClick > 0.5f) {
			clickedT = !clickedT;
			lastClick = 0.f;
		}
		if (input->rawInput[DD_Keys::Space_Key] && lastClick > 0.5f) {
			clickedSpace = !clickedSpace;
			lastClick = 0.f;
		}
		if (input->rawInput[DD_Keys::R_Key] && lastClick > 0.5f) {
			clickedLA = !clickedLA;
			lastClick = 0.f;
		}
		if (input->rawInput[DD_Keys::F_Key] && lastClick > 0.5f) {
			clickedRA = !clickedRA;
			lastClick = 0.f;
		}
		if (input->mouseLMR[2]) {
			//printf("X: %d Y: %d     \r", input->mouseXDelta, input->mouseYDelta);
			Pitch += input->mouseYDelta * mouseSensitivity * event.m_time;
			Yaw += input->mouseXDelta * mouseSensitivity * event.m_time;
			// constrain pitch to fps style camera (radians)
			if (Pitch > 1.3f) {
				Pitch = 1.3f;
			}
			if (Pitch < -1.3f) {
				Pitch = -1.3f;
			}
			glm::quat newRot = glm::quat(glm::vec3(Pitch, Yaw, 0.0f));
			UpdateRotation( glm::lerp(rot(), newRot, 0.5f) );
		}

		//*/
	}
	return DD_Event();
}
