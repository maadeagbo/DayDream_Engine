#pragma once

#include "DD_GameLevel.h"
#include "Controller.h"
#include "config.h"

class LightScene : public DD_GameLevel
{
public:
	LightScene();
	~LightScene() {}

	DD_Event basePost(DD_Event& event);
private:

};