#pragma once

#include "DD_Agent.h"

class ControllerL : public DD_Agent {
public:
	ControllerL(const char* ID, const char* model = "", const char* parent = "");
	~ControllerL() {}

	DD_Event Update(DD_Event event);

	bool clickedP, clickedT, clickedSpace, clickedRA, clickedLA;
private:

};
