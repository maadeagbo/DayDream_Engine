#include "SimpleAgent.h"

SimpleAgent::SimpleAgent(const char* ID, const char* model, const char* parent) : 
	DD_Agent(ID, model, parent)
{

}

DD_Event SimpleAgent::SimpleHandler(DD_Event event) {
	DD_Event new_event = DD_Event();

	return new_event;
}
