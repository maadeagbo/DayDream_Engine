#pragma once

#include "DD_Agent.h"

class SimpleAgent : public DD_Agent {
public:
	SimpleAgent(const char* ID, const char* model = "", const char* parent = "");
	~SimpleAgent() {}

	DD_Event SimpleHandler(DD_Event event);
private:

};