#pragma once

#include "config.h"
#include "DD_MathLib.h"
#include "DD_GameLevel.h"
#include "ControllerT.h"

class TownVR : public DD_GameLevel
{
public:
	TownVR() {}
	~TownVR() {}

	void Init();
	DD_Event basePost(DD_Event& event);
private:

};