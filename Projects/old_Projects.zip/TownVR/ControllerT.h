#pragma once

#include "DD_Agent.h"

class ControllerT : public DD_Agent {
public:
	ControllerT(const char* ID, const char* model = "", const char* parent = "");
	~ControllerT() {}

	DD_Event Update(DD_Event& event);

	bool clickedP = false, clickedT = false, clickedSpace = false, 
		clickedRA = false, clickedLA = false, clickedLM = false, clickedEsc = false;
	int mouseX = 0.f, mouseY = 0.f;
private:

};
