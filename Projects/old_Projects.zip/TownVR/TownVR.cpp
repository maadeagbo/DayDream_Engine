#include "TownVR.h"

#include <vrpn_Tracker.h>

namespace {
	enum sims { WATER, FIRE, MAGIC, BALL, CLOTH, NUM_SIMS };

	ControllerT* myControl;
	DD_Camera* cam;
	DD_Light* light;
	DD_Agent* bunny;
	int mouseXPos = 0.f, mouseYPos = 0.f;
    float ground_gap = 100.f, b_pos[3];

	std::string trackedOBJ = "Eyes2@motion02-umh.cs.umn.edu";
	std::string trackedTV = "TV@motion02-umh.cs.umn.edu";
	vrpn_Tracker_Remote* vrpnAnalog, *vrpnAnalogTV;
	glm::vec3 head_pos, tv_pos;
	glm::quat head_quat;
	bool VR_FLAG = false;
}

void VRPN_CALLBACK handle_analog(void* userData, const vrpn_TRACKERCB a) {
	//printf("Position: %.3f, %.3f, %.3f\n", a.pos[0], a.pos[1], a.pos[2]);
	head_pos.x = a.pos[0];
	head_pos.y = a.pos[1];
	head_pos.z = a.pos[2];

	head_quat.x = a.quat[0];
	head_quat.y = a.quat[1];
	head_quat.z = a.quat[2];
	head_quat.w = a.quat[3];
	//cout << "Rotation: " << a.pos[0] << ", " << a.pos[1] << ", " << a.pos[2] << endl;
}

void VRPN_CALLBACK handle_analogTV(void* userData, const vrpn_TRACKERCB a) {
	//printf("Position: %.3f, %.3f, %.3f\n", a.pos[0], a.pos[1], a.pos[2]);
	tv_pos.x = a.pos[0];
	tv_pos.y = a.pos[1];
	tv_pos.z = a.pos[2];
	//cout << "Rotation: " << a.pos[0] << ", " << a.pos[1] << ", " << a.pos[2] << endl;
}


void TownVR::Init() {
	if (VR_FLAG) {
		vrpnAnalog = new vrpn_Tracker_Remote(trackedOBJ.c_str());
		vrpnAnalogTV = new vrpn_Tracker_Remote(trackedTV.c_str());
		vrpnAnalog->register_change_handler(0, handle_analog);
		vrpnAnalogTV->register_change_handler(0, handle_analogTV);
	}

	// add resource file containing all assets
	m_resourceFile = PROJECT_DIR + "TownVR/assets";
	// register skybox map
	m_cubeMapID = "water";
	// add meshes to level
	myControl = new ControllerT("avatar");
	AddAgent(myControl);
	myControl->clickedP = false;
	myControl->clickedT = false;
	myControl->clickedSpace = false;
	myControl->UpdatePosition(glm::vec3(0.0f, 180.0f, 500.0f));

	bunny = GetGenericAgent("Bunny", "bunny");
	b_pos[0] = 0.f;
	b_pos[1] = 100.f;
	b_pos[2] = 0.f;
	bunny->UpdatePosition(glm::vec3(b_pos[0], b_pos[1], b_pos[2]));
	bunny->UpdateScale(glm::vec3(0.25f));

	DD_Agent* t1 = GetGenericAgent("t1", "town_01");
	DD_Agent* t2 = GetGenericAgent("t2", "town_02");
	DD_Agent* t3 = GetGenericAgent("t3", "town_03");
	DD_Agent* t4 = GetGenericAgent("t4", "town_04");
	DD_Agent* t5 = GetGenericAgent("t5", "town_05");
	DD_Agent* t6 = GetGenericAgent("t6", "town_06");
	DD_Agent* t7 = GetGenericAgent("t7", "town_07");
	DD_Agent* t8 = GetGenericAgent("t8", "town_08");
	DD_Agent* t9 = GetGenericAgent("t9", "town_09");
	DD_Agent* t10 = GetGenericAgent("t10", "town_10");
	DD_Agent* t11 = GetGenericAgent("t11", "town_11");
	DD_Agent* t12 = GetGenericAgent("t12", "town_12");
	DD_Agent* t13 = GetGenericAgent("t13", "town_13");
	DD_Agent* t14 = GetGenericAgent("t14", "town_14");
	DD_Agent* t15 = GetGenericAgent("t15", "town_15");
	DD_Agent* t16 = GetGenericAgent("t16", "town_16");
	DD_Agent* t17 = GetGenericAgent("t17", "town_17");
	DD_Agent* t18 = GetGenericAgent("t18", "town_18");
	DD_Agent* t19 = GetGenericAgent("t19", "town_19");
	DD_Agent* t20 = GetGenericAgent("t20", "town_20");
	DD_Agent* t21 = GetGenericAgent("t21", "town_21");
	DD_Agent* t22 = GetGenericAgent("t22", "town_22");
	DD_Agent* t23 = GetGenericAgent("t23", "town_23");
	DD_Agent* t24 = GetGenericAgent("t24", "town_24");
	DD_Agent* tf = GetGenericAgent("t_f", "town_floor");
	glm::vec3 scale = glm::vec3(0.5);
	t1->UpdateScale(scale);//t1->pos() + glm::vec3(0.f, -100.f, 0.f));
	t2->UpdateScale(scale);//t2->pos() + glm::vec3(0.f, -100.f, 0.f));
	t3->UpdateScale(scale);//t3->pos() + glm::vec3(0.f, -100.f, 0.f));
	t4->UpdateScale(scale);//t4->pos() + glm::vec3(0.f, -100.f, 0.f));
	t5->UpdateScale(scale);//t5->pos() + glm::vec3(0.f, -100.f, 0.f));
	t6->UpdateScale(scale);//t6->pos() + glm::vec3(0.f, -100.f, 0.f));
	t7->UpdateScale(scale);//t7->pos() + glm::vec3(0.f, -100.f, 0.f));
	t8->UpdateScale(scale);//t8->pos() + glm::vec3(0.f, -100.f, 0.f));
	t9->UpdateScale(scale);//t9->pos() + glm::vec3(0.f, -100.f, 0.f));
	t10->UpdateScale(scale);//t10->pos() + glm::vec3(0.f, -100.f, 0.f));
	t11->UpdateScale(scale);//t11->pos() + glm::vec3(0.f, -100.f, 0.f));
	t12->UpdateScale(scale);//t12->pos() + glm::vec3(0.f, -100.f, 0.f));
	t13->UpdateScale(scale);//t13->pos() + glm::vec3(0.f, -100.f, 0.f));
	t14->UpdateScale(scale);//t14->pos() + glm::vec3(0.f, -100.f, 0.f));
	t15->UpdateScale(scale);//t15->pos() + glm::vec3(0.f, -100.f, 0.f));
	t16->UpdateScale(scale);//t16->pos() + glm::vec3(0.f, -100.f, 0.f));
	t17->UpdateScale(scale);//t17->pos() + glm::vec3(0.f, -100.f, 0.f));
	t18->UpdateScale(scale);//t18->pos() + glm::vec3(0.f, -100.f, 0.f));
	t19->UpdateScale(scale);//t19->pos() + glm::vec3(0.f, -100.f, 0.f));
	t20->UpdateScale(scale);//t20->pos() + glm::vec3(0.f, -100.f, 0.f));
	t21->UpdateScale(scale);//t21->pos() + glm::vec3(0.f, -100.f, 0.f));
	t22->UpdateScale(scale);//t22->pos() + glm::vec3(0.f, -100.f, 0.f));
	t23->UpdateScale(scale);//t23->pos() + glm::vec3(0.f, -100.f, 0.f));
	t24->UpdateScale(scale);//t24->pos() + glm::vec3(0.f, -100.f, 0.f));
	tf->UpdateScale(scale);//tf->pos() + glm::vec3(0.f, -100.f, 0.f));
	
	// Add shadow light
	light = GetGenericLight("shadow");
	light->m_position = glm::vec3(3000.0f, 3000.f, 2000.0f);
	light->m_color = glm::vec3(1.f);
	light->m_flagShadow = true;

	// add generic camera
	cam = GetGenericCamera("myCam");
	cam->m_active = true;
	cam->m_near_plane = 0.1f;
	cam->m_far_plane = 3000.0f;
	cam->SetParent(myControl->m_ID.c_str());
	cam->m_vr_cam = VR_FLAG;
	cam->m_vr_window = VR_FLAG;
	if (cam->m_vr_cam) {
		cam->m_vrScrPos = glm::vec3(0.0f, 0.0f, 0.0f);
		cam->m_vrEyePos = myControl->pos();
		m_scrHorzDist = 0.9271f;
		m_scrVertDist = 0.5207f;
		cam->m_eyeDist = 0.3f;
	}
	//  callbacks and posts
	EventHandler a = std::bind(&TownVR::basePost, this, std::placeholders::_1);
	AddCallback("post", a);
	AddCallback("VR", a);
}

DD_Event TownVR::basePost(DD_Event& event) {
	if (event.m_type == "VR") {
		if (VR_FLAG) {
			vrpnAnalog->mainloop();
			vrpnAnalogTV->mainloop();

			myControl->UpdatePosition(head_pos * 1.f);
			//myControl->UpdatePosition(head_pos);
			if (cam->m_vr_window = false) {
				myControl->UpdateRotation(glm::lerp(myControl->rot(), head_quat, 0.5f));
			}
			bunny->UpdatePosition(tv_pos);

			cam->m_vrScrPos = bunny->pos();
			cam->m_vrEyePos = myControl->pos();
		}
		return DD_Event();
	}
	if (event.m_type.compare("post") == 0) {
		//* imgui interface sims
		ImGuiWindowFlags window_flags = 0;
		ImGui::Begin("VR Controls", nullptr, window_flags);
		ImGui::SliderFloat("Eye Dist", &cam->m_eyeDist, -1.f, 1.f);
		ImGui::SliderFloat3("Bunny", b_pos, -100.f, 100.f);
		if (ImGui::Button("Reset Bunny")) {
			b_pos[0] = 0.f;
			b_pos[1] = 100.f;
			b_pos[2] = 0.f;
		}
		//ImGui::SameLine();
		//if (ImGui::RadioButton("Fire", simFlags[1])) simFlags[1] ^= 1;
		//ImGui::SameLine();
		ImGui::End();
		//*/

		// update bunny's location
		//->UpdatePosition(glm::vec3(b_pos[0], b_pos[1], b_pos[2]));

		timeData* time = static_cast<timeData*>(event.m_message);
		// ground level cam
		if (myControl->pos().y < ground_gap) {
			glm::vec3 _pos = myControl->pos();
			myControl->UpdatePosition(glm::vec3(_pos.x, ground_gap, _pos.z));
		}
		if (myControl->clickedLM) {
			myControl->clickedLM = false;

            mouseXPos = myControl->mouseX;
			mouseYPos = myControl->mouseY;

			raycastBuff rcb = DD_MathLib::rayCast(mouseXPos, mouseYPos, "Floor");
			if (rcb.hit == true) {
				//printf("Hit: x: %f, y: %f, z: %f\n", 
				//	rcb.pos.x, rcb.pos.y, rcb.pos.z);
			}
		}
		return DD_Event();
	}
}
