#pragma once

#include "DD_GameLevel.h"
#include "Controller.h"
#include "config.h"

class BaseLevel : public DD_GameLevel
{
public:
	BaseLevel();
	~BaseLevel() {}

	DD_Event baseUpdate(DD_Event& event);
	DD_Event basePost(DD_Event& event);
private:

};