#pragma once

#include "DD_Agent.h"

class Controller : public DD_Agent {
public:
	Controller(const char* ID, const char* model = "", const char* parent = "");
	~Controller() {}

	DD_Event Update(DD_Event event);

	bool clickedP, clickedT, clickedSpace, clickedRA, clickedLA;
private:

};
