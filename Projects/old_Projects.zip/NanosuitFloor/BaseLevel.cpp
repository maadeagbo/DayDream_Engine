#include "BaseLevel.h"

namespace {
	enum sims { WATER, FIRE, MAGIC, BALL, CLOTH, NUM_SIMS };

	Controller* myControl;
	DD_Agent* ball;
	DD_Camera* cam;
	DD_Light* light;
	glm::vec3 ball_hold_Dist = glm::vec3(), ballVel = glm::vec3();
	bool makeParticleFlag = true;
	bool throwBallFlag = false, inHandFlag = false;
	bool simFlags[sims::NUM_SIMS] = { false, false, false, false, true };
	int fireCount = 0, emitterIndex = 0;

	// cloth UI
	bool clothCreated = false;
	float ws_X = 0.f, ws_Y = 0.f, ws_Z = 0.f;
}

BaseLevel::BaseLevel() {
	// add resource file containing all assets
	m_resourceFile = PROJECT_DIR + "NanosuitFloor/assets";
	// register skybox map
	//m_cubeMapID = "water";
	// add meshes to level
	myControl = new Controller("avatar");
	AddAgent(myControl);
	myControl->clickedP = false;
	myControl->clickedT = false;
	myControl->clickedSpace = false;
	myControl->UpdatePosition(glm::vec3(0.0f, 80.0f, 500.0f));
	ball_hold_Dist = myControl->ForwardDir() * 500.0f;

	//DD_Agent* agent1 = GetGenericAgent("Floor", "floor");
	//agent1->UpdateScale(glm::vec3(100.f));

	ball = GetGenericAgent("Ball_Red", "ball");
	ball->UpdateScale(glm::vec3(4.f));
	//DD_Agent* agent3 = GetGenericAgent("Black_Guy", "dude");
	//agent3->UpdateScale(glm::vec3(10.f));

	/*
	DD_Agent* agentA = GetGenericAgent("Tree01", "tree3");
	agentA->UpdatePosition(glm::vec3(1360.1f, 0.0f, 174.1f));
	dd_array<glm::mat4> mats(12);
	mats[0] = glm::translate(glm::mat4(), glm::vec3(-708.4f, 0.0f, -783.7f));
	mats[1] = glm::translate(glm::mat4(), glm::vec3(-986.f, 0.0f, 1208.3f));
	mats[2] = glm::translate(glm::mat4(), glm::vec3(-1022.3f, 0.0f, 434.9f));
	mats[3] = glm::translate(glm::mat4(), glm::vec3(-1193.f, 0.0f, -148.f));
	mats[4] = glm::translate(glm::mat4(), glm::vec3(-972.1f, 0.0f, 852.6f));
	mats[5] = glm::translate(glm::mat4(), glm::vec3(-1048.8f, 0.0f, -994.5f));
	mats[6] = glm::translate(glm::mat4(), glm::vec3(822.5f, 0.0f, -750.f));
	mats[7] = glm::translate(glm::mat4(), glm::vec3(355.1f, 0.0f, -24.1f));
	mats[8] = glm::translate(glm::mat4(), glm::vec3(-436.f, 0.0f, -437.f));
	mats[9] = glm::translate(glm::mat4(), glm::vec3(-258.9f, 0.0f, -588.7f));
	mats[10] = glm::translate(glm::mat4(), glm::vec3(605.9f, 0.0f, 678.9f));
	mats[11] = glm::translate(glm::mat4(), glm::vec3(-482.3f, 0.0f, 182.3f));
	agentA->SetInstances(mats);
	//*/

	// Add shadow light
	light = GetGenericLight("shadow");
	light->m_position = glm::vec3(1000.0f, 1000.f, 2000.0f);
	light->m_color = glm::vec3(1.f, 1.f, 0.5f);
	//light->m_flagShadow = true;

	// fire light
	//DD_Light* FL01 = GetGenericLight("fire");
	//FL01->m_type == LightType::POINT_L;
	//FL01->m_attenuation = .001;

	// add generic camera
	cam = GetGenericCamera("myCam");
	cam->m_active = true;
	cam->m_far_plane = 8000.0f;
	cam->SetParent(myControl->m_ID.c_str());
	cam->m_vr_cam = false;
	if (cam->m_vr_cam) {
		cam->m_vrScrPos = glm::vec3(0.0f, 0.0f, 0.0f);
		cam->m_vrEyePos = myControl->pos();
		m_scrHorzDist = 0.9271f;
		m_scrVertDist = 0.5207f;

		// update eye position input
		EventHandler lvlUpdate =
			std::bind(&BaseLevel::baseUpdate, this, std::placeholders::_1);
		AddCallback("VR", lvlUpdate);
	}

	//  callbacks and posts
	EventHandler a = std::bind(&BaseLevel::basePost, this, std::placeholders::_1);
	AddCallback("post", a);
}

DD_Event BaseLevel::baseUpdate(DD_Event& event) {
	if (event.m_type == "VR") {
		cam->m_vrEyePos = myControl->pos();
	}
	return DD_Event();
}

// use this function to calculate ball bounce
void CalcBallLoc(glm::vec3& pos, const float radius, glm::vec3& vel, float deltaT)
{
    glm::vec3 oldP = pos;
    glm::vec3 oldV = vel;

    // Force of gravity
    float InvMassPtcl = 1.f/5.f;
    glm::vec3 F = (1.f/InvMassPtcl) * glm::vec3(0.0, -981.0, 0.0);

    // Euler equation
    glm::vec3 accel = F * InvMassPtcl;
    pos = glm::vec3(oldP + oldV * deltaT + 0.5f * accel * deltaT * deltaT);
    vel = glm::vec3(oldV + accel * deltaT);

    // ground bounce
    if(pos.y < radius) {
        pos.y = radius;
        vel.y *= -1.f * 0.8f;  // bounce
		vel *= 0.98f;		   // friction
    }
}

DD_Event BaseLevel::basePost(DD_Event& event) {

	if (event.m_type.compare("post") == 0) {
		timeData* time = static_cast<timeData*>(event.m_message);
		/* imgui interface sims
		ImGuiWindowFlags window_flags = 0;
		ImGui::Begin("Particle Controls", nullptr, window_flags);
		if (ImGui::RadioButton("Water", simFlags[0])) simFlags[0] ^= 1;
		ImGui::SameLine();
		if (ImGui::RadioButton("Fire", simFlags[1])) simFlags[1] ^= 1;
		ImGui::SameLine();
		if (ImGui::RadioButton("Magic", simFlags[2])) simFlags[2] ^= 1;
		ImGui::SameLine();
		if (ImGui::RadioButton("Ball", simFlags[3])) simFlags[3] ^= 1;
		ImGui::SameLine();
		if (ImGui::RadioButton("Cloth", simFlags[4])) simFlags[4] ^= 1;
		ImGui::End();
		//*/

		makeParticleFlag = myControl->clickedP;
		throwBallFlag = myControl->clickedSpace;

		// ground level cam
		if (myControl->pos().y < 50.0f) {
			glm::vec3 _pos = myControl->pos();
			//myControl->UpdatePosition(glm::vec3(_pos.x, 50.0f, _pos.z));
		}

		if (makeParticleFlag && !inHandFlag && simFlags[sims::BALL]) {

			ball->UpdatePosition(ball_hold_Dist);
			ball->SetParent("avatar");

			inHandFlag = true;
			myControl->clickedP = false;
		}
		if (throwBallFlag && inHandFlag && simFlags[sims::BALL]) {
			glm::vec3 lDir = myControl->ForwardDir() * 2000.f;
			ballVel = lDir;

			glm::vec3 p = glm::vec3(ball->m_parentTransform * glm::vec4(ball->pos(), 1.f));
			CalcBallLoc(p, 0.1f, ballVel, time->frameTime);
			ball->UpdateRotation(myControl->rot());
			ball->UpdatePosition(p);

			ball->unParent();

			inHandFlag = false;
			myControl->clickedSpace = false;
		}
		if (!inHandFlag && simFlags[sims::BALL] && time->gameTime > 5.f) {
			glm::vec3 p = ball->pos();
			CalcBallLoc(p, 0.1f, ballVel, time->frameTime);
			ball->UpdatePosition(p);
		}
		if (makeParticleFlag && simFlags[sims::WATER]) {
			DD_Event newEvent = DD_Event();
			newEvent.m_type = "generate_emitter";

			emitterInit* init = new emitterInit();
			init->ID = "water";
			init->textureSet = RenderTextureSets::B_BALL;
			init->parentID = "";
			init->radius = 50.f;
			init->type = EmitterType::WATER;
			init->size = 4.f;
			glm::mat4 mat = glm::translate(glm::mat4(), glm::vec3(0.f, 120.f, 70.f));
			init->model = mat;
			init->lifetime = 20.f;
			init->emitPerSec = 200.0f;
			init->deathRate = 10.0;
			init->rotPerSec = 0;
			init->direction = glm::rotate(glm::mat4(), glm::radians(45.f),
				glm::vec3(1.f, 0.f, 0.f));
			init->velUp = 800.0f;

			newEvent.m_message = init;
			myControl->clickedP = false;

			return newEvent;
		}
		if (makeParticleFlag && simFlags[sims::FIRE]) {
			DD_Event newEvent = DD_Event();
			newEvent.m_type = "generate_emitter";

			emitterInit* init = new emitterInit();
			init->ID = "fire" + std::to_string(fireCount);
			fireCount += 1;

			init->textureSet = RenderTextureSets::FIRE01;
			init->parentID = "";
			init->radius = 50.f;
			init->type = EmitterType::FIRE;
			init->size = 4.f;

			glm::vec3 myP = myControl->pos();
			myP += myControl->ForwardDir() * 500.f;
			glm::mat4 mat = glm::translate(glm::mat4(), glm::vec3(myP.x, 0.f, myP.z));

			init->model = mat;
			init->lifetime = 10.f;
			init->emitPerSec = 1000.0f;
			init->deathRate = 2.0;
			init->rotPerSec = 2;
			init->direction = glm::rotate(glm::mat4(), glm::radians(5.f),
				glm::vec3(0.f, 0.f, 1.f));
			init->velUp = 150.0f;

			newEvent.m_message = init;
			myControl->clickedP = false;

			return newEvent;
		}
		if (makeParticleFlag && simFlags[sims::MAGIC]) {
			DD_Event newEvent = DD_Event();
			newEvent.m_type = "generate_emitter";

			emitterInit* init = new emitterInit();
			init->ID = "smoke";
			init->textureSet = RenderTextureSets::NA;
			init->parentID = "";
			init->radius = 100.f;
			init->type = EmitterType::MAGIC;
			init->size = 6.f;
			glm::mat4 mat = glm::translate(glm::mat4(), glm::vec3(0.f, 1000.f, 0.f));
			init->model = mat;
			init->lifetime = 100.f;
			init->emitPerSec = 1000.0f;
			init->deathRate = 5.0;
			init->rotPerSec = 0;
			init->direction = glm::rotate(glm::mat4(), glm::radians(0.f),
				glm::vec3(0.f, 0.f, 1.f));
			init->velUp = 0.0f;

			newEvent.m_message = init;
			myControl->clickedP = false;

			return newEvent;
		}

		if (makeParticleFlag && simFlags[sims::CLOTH]) {
			DD_Event newEvent = DD_Event();
			newEvent.m_type = "create_cloth";

			clothInit* init = new clothInit();
			init->ID = "test_cloth";
			init->pointDist = 5.f;
			init->firstPoint = glm::vec3(-200.f, 200.f, 0.f);
			init->rowSize = 100;
			init->colSize = 100;

			newEvent.m_message = init;
			myControl->clickedP = false;
			clothCreated = true;

			return newEvent;
		}

		if (clothCreated) {
			ImGuiWindowFlags window_flags = 0;
			ImGui::Begin("Wind Accel", nullptr, window_flags);
			ImGui::SliderFloat("X axis", &ws_X, -1000.f, 1000.f);;
			ImGui::SliderFloat("y axis", &ws_Y, -1000.f, 1000.f);;
			ImGui::SliderFloat("Z axis", &ws_Z, -1000.f, 1000.f);;
			ImGui::End();

			DD_Event newEvent = DD_Event();
			newEvent.m_type = "update_cloth";

			clothUpdate* init = new clothUpdate();
			init->ID = "test_cloth";
			init->windSpeed = glm::vec3(ws_X, ws_Y, ws_Z);
			init->ball_pos = ball->pos();
			init->ball_mass = 1.0;
			init->ball_velocity = ballVel;
			init->ball_radius = 42.f * ball->size().x;

			newEvent.m_message = init;
			return newEvent;
		}

		if (myControl->clickedT) {
			event.m_type = "system_pause";

			myControl->clickedT = false;
		}


		return DD_Event();
	}
}
