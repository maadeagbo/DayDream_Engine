#include "TownLevel.h"

namespace {
	TownAvatar* camAvatar;
	DD_Camera* camBase;
}

TownLevel::TownLevel() {
	// add resource file containing all assets
	m_resourceFile = PROJECT_DIR + "Town/town";
	// register skybox map
	m_cubeMapID = "water";
	// add DD_Agents to level
	TownAgent* townP1 = new TownAgent("building01", "town_01");
	TownAgent* townP2 = new TownAgent("building02", "town_02");
	TownAgent* townP3 = new TownAgent("building03", "town_03");
	TownAgent* townP4 = new TownAgent("building04", "town_04");
	TownAgent* townP5 = new TownAgent("building05", "town_05");
	AddAgent(townP1);
	AddAgent(townP2);
	AddAgent(townP3);
	AddAgent(townP4);
	AddAgent(townP5);

	camAvatar = new TownAvatar("avatar");
	AddAgent(camAvatar);
	camAvatar = camAvatar;
	camAvatar->UpdatePosition(glm::vec3(0.0f, 100.0f, 1000.0f));

	// add generic camera
	camBase = GetGenericCamera("myCam");
	camBase->m_active = true;
	//camBase->updateCamera(glm::vec4(0.0f, 100.0f, -1000.0f, 1.0f), 
		//glm::quat(glm::vec3(0.0f, glm::radians(180.0f), 0.0f)));
	camBase->SetParent(camAvatar->m_ID.c_str());
	camBase->m_vr_cam = false;
	if (camBase->m_vr_cam) {
		camBase->m_vrScrPos = glm::vec3(0.0f, 0.0f, 0.0f);
		camBase->m_vrEyePos = camAvatar->pos();
		m_scrHorzDist = 0.9271f;
		m_scrVertDist = 0.5207f;

		// update eye position input
		EventHandler lvlUpdate =
			std::bind(&TownLevel::townUpdate, this, std::placeholders::_1);
		AddCallback("VR", lvlUpdate);
	}
}

DD_Event TownLevel::townUpdate(DD_Event& event) {
	if (event.m_type == "VR") {
		camBase->m_vrEyePos = camAvatar->pos();
	}
	return DD_Event();
}