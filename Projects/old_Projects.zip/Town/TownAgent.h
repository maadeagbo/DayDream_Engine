#pragma once

#include "DD_Agent.h"

class TownAgent : public DD_Agent {
public:
	TownAgent(const char* ID, const char* model = "", const char* parent = "");
	~TownAgent() {}

	DD_Event Update(DD_Event& event);
private:

};