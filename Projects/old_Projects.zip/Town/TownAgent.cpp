#include "TownAgent.h"

TownAgent::TownAgent(const char* ID, const char* model, const char* parent) : 
	DD_Agent(ID, model, parent)
{
	// store function pointer
	EventHandler update = 
		std::bind(&TownAgent::Update, this, std::placeholders::_1);

	AddCallback("input", update);
}

DD_Event TownAgent::Update(DD_Event& event) {
	return DD_Event();
}
