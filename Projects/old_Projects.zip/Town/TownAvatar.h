#pragma once

#include "DD_Agent.h"

class TownAvatar : public DD_Agent {
public:
	TownAvatar(const char* ID, const char* model = "", const char* parent = "");
	~TownAvatar() {}

	DD_Event Update(DD_Event& event);
private:

};