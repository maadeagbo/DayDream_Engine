#pragma once

#include "DD_GameLevel.h"
#include "TownAgent.h"
#include "TownAvatar.h"
#include "config.h"

class TownLevel : public DD_GameLevel
{
public:
	TownLevel();
	~TownLevel() {}

	DD_Event townUpdate(DD_Event& event);
private:

};