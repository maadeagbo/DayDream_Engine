#include "TownAvatar.h"

namespace {
	float speed = 500.0f;
}

TownAvatar::TownAvatar(const char * ID, const char * model, const char * parent) {
	m_ID = ID;
	// store function pointer
	EventHandler update =
		std::bind(&TownAvatar::Update, this, std::placeholders::_1);

	AddCallback("input", update);
}

DD_Event TownAvatar::Update(DD_Event& event) {
	// Parse throught events
	if (event.m_type == "input") {
		glm::vec3 forward = ForwardDir() * speed * event.m_time;
		glm::vec3 right = RightDir() * speed * event.m_time;
		//*
		inputBuff* input = (inputBuff*)event.m_message;
		if (input->rawInput[DD_Keys::W_Key]) {
			UpdatePosition(pos() + forward);
			//printf("W: %f, %f, %f \n", pos().x, pos().y, pos().z);
		}
		if (input->rawInput[DD_Keys::A_Key]) {
			UpdatePosition(pos() - right);
			//printf("A: %f, %f, %f \n", pos().x, pos().y, pos().z);
		}
		if (input->rawInput[DD_Keys::S_Key]) {
			UpdatePosition(pos() - forward);
			//printf("S: %f, %f, %f \n", pos().x, pos().y, pos().z);
		}
		if (input->rawInput[DD_Keys::D_Key]) {
			UpdatePosition(pos() + right);
			//printf("D: %f, %f, %f \n", pos().x, pos().y, pos().z);
		}
		//*/
	}
	return DD_Event();
}
